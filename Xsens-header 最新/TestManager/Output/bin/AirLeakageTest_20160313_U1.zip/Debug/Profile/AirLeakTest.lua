Module="Air_Leakage_Test"			--Module Name
Version="Script Version 20160311 V1.0"						--Version add write factor
Customer="Apple"					--Customer ID
StationID=""					--Station ID
LineID=""					--Line ID
FixtureID=""					--Fixture ID
DirInLogPath="FCT"

DutIndex=0

local IDTable={};
local SF=1;

function Test_OnEntry(par)		--Initial function for startup test,you can add test initial code in here
	DutIndex = fixture.GetDutIndex()
	DbgOut("DutIndex:"..DutIndex)
	return 0
--[[	-- Check Raster
	if (fixture.CheckRaster(DutIndex) == 1) then
			--assert(true)
	end

	-- V11 on V12 off
	if (fixture.FixtureAirCylinderUpAction(DutIndex,"on") ~= 0) then
		return -1
	end
	
	-- V7 on V8 off
	if (fixture.HoldAirCylinderOutAction(DutIndex,"on") ~= 0) then
		return -1
	end
	
	-- V1 on
	if (fixture.MainAirSolenoidValveAction("on") ~= 0) then
		return -1
	end
	
	-- V2 on 
	if (fixture.PositiveAirSolenoidValveAction(DutIndex,"on") ~= 0) then
		return -1
	end
	
	-- V4 on 
	if (fixture.NegativeAirSolenoidValveAction(DutIndex,"on") ~= 0) then
		return -1
	end
	
	-- V6 on
	if (fixture.VacuumAction("on") ~= 0) then
		return -1
	end
	
	-- Check Presure	--Maybe we need time to wait for it done..
	if (fixture.CheckPresureSwitch("on") ~= 0) then
		return -1
	end
	
	-- V1 off
	if (fixture.MainAirSolenoidValveAction("off") ~= 0) then
		return -1
	end
	
	-- V6 off
	if (fixture.VacuumAction("off") ~= 0) then
		return -1
	end
	
	
	-- V3 on
	if (PositiveAirSolenoidValveAction((1-DutIndex),"on") ~= 0) then
		return -1
	end--]]
end

function Test_OnAbort(par)
	--fixture.PerformDutReset()
	--Perform_CompletedTest()
	Perfrom_C28StopTest()
	Delay(2000)
end

function Test_OnFail(par)		--Clear function for test failed,you can add clear function code in here when test failed.
	--fixture.PerformDutReset()
	--Perform_CompletedTest()
end

function Test_OnDone(par)		--Clear function for normal test finish.you can add clear function code in there when test normally finish.	
	--fixture.PerformDutReset()	
	--Perform_CompletedTest()
end

function TestFunc()
	Delay(1000)
	return 0
end

function Perfrom_C28Test()
	local strRead
	c28.ClearBuffer()
	c28.SetDetectString("Stop");
	c28.WriteString("\r\nM\\S1TStart\r\n")
	
	if c28.WaitForString(20000) ~=-1 then
		Delay(1000)
		strRead = c28.ReadString();
		Delay(1000)
		strRead = strRead..tostring(c28.ReadString())
		DbgOut(tostring(strRead))
		if(strRead ~= nil) then
			if (string.find(strRead,"SL -") ~= nil) then
				return -1
			end
			
			local PL,Pt,EDC,PLR,FPR,LOF = string.match(strRead,"PL%s+([%.%-%d]+)%s+dPa%s+Pt%s+([%-%.%d]+)%s+kPa%s+EDC%s+([%.%-%d]+)%s+dPa%s+PLR%s+([%.%-%d]+)%s+dPa%s+FPR%s+([%.%-%d]+)%s+kPa%s+LOF%s+([%.%-%d]+)%s+dPa")
			DbgOut("PL:"..PL.."\nPT:"..PT.."\nEDC:"..EDC.."\nPLR:"..PLR.."\nFPR:"..FPR.."\nLOF:"..LOF)
			return tonumber(PL)
		end
	end

	DbgOut("Failed:"..tostring(strRead))

end


function Perfrom_C28StopTest()
	local strRead
	DbgOut("Perfrom_C28StopTest")
	c28.WriteString("\r\nM\\S1TStop\r\n")
	c28.ClearBuffer()
end




function Perform_CompletedTest()
	-- V2 off
	if (fixture.PositiveAirSolenoidValveAction(DutIndex,"on") ~= 0) then
		return -1
	end
	
	-- V3 off
	if (PositiveAirSolenoidValveAction((1-DutIndex),"off") ~= 0) then
		return -1
	end
	
	-- V4 off 
	if (fixture.NegativeAirSolenoidValveAction(DutIndex,"off") ~= 0) then
		return -1
	end
	
	-- V7 off
	if (fixture.HoldAirCylinderOutAction(DutIndex,"off") ~= 0) then
		return -1
	end
	
	-- V11 off
	if (fixture.FixtureAirCylinderUpAction(DutIndex,"off") ~= 0) then
		return -1
	end
end



local AIR_LEAKAGE_CHECK_Sub={
	{name="Air_Leakage_Test",lower=1,upper=2,unit="dPa",entry=Perfrom_C28Test,parameter={id=ID},visible=1},
};


local AIR_LEAKAGE_CHECK_Item={name="Air_Leakage_Test",entry=nil,parameter=nil,sub=AIR_LEAKAGE_CHECK_Sub};

items = 
{
	AIR_LEAKAGE_CHECK_Item,
}