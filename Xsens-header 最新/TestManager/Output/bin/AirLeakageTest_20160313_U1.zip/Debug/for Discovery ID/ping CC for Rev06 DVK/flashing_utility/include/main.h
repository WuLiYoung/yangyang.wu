#ifndef _MAIN_H__
#define _MAIN_H__

#include <stdio.h>
#include <conio.h>
#include <windows.h>


#endif /* _MAIN_H__ */