//
//  CZDownloadMusic.m
//  --ios音乐播放器
//
//  Created by 吴洋洋 on 16/3/4.
//  Copyright © 2016年 吴洋洋. All rights reserved.
//

#import "CHDownloadMusic.h"

@implementation CHDownloadMusic

//+ (instancetype)downloadWithDic: (NSDictionary *)dic
//{
//    id dm = [[self alloc] init];
//    
//    [dm setValuesForKeysWithDictionary:dic];
//    
//    return dm;
//}

@end
